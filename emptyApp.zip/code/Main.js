class Main extends lang.display.Sprite{

constructor(){
alert('Hello World')
}

}